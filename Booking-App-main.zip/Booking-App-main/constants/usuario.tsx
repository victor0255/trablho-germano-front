const usuarios = [
    {id: 1, nome:"Marta Souza", nome_grupo:"Profissional"},
    {id: 2, nome:"Maria Joana", nome_grupo:"Cliente"},
    {id: 3, nome:"Jose Bento", nome_grupo:"Profissional"},
    {id: 4, nome:"Joao Carlos", nome_grupo:"Cliente"},
    {id: 5, nome:"Joana Silva", nome_grupo:"Cliente"},
    {id: 6, nome:"Josue Dantas", nome_grupo:"Profissional"},
    {id: 7, nome:"Simao Sillas", nome_grupo:"Cliente"},
    {id: 8, nome:"Pedro Jose", nome_grupo:"Cliente"},
    {id: 9, nome:"Joaquim Silva", nome_grupo:"Cliente"},
    {id: 10, nome:"Fernando Alves", nome_grupo:"Cliente"},
]

export const Usuarios = function(){
    return usuarios;
}
